% You have to fill in the code in this function for Task 1B
% (Hessian
function features = computeTask1BFeatures( image )

% features should be a matrix for which the value
%   features(I,J) is the value of the feature J at pixel I

% This is an example that just places the pixels values in the feature
% matrix
% You HAVE TO RE-IMPLEMENT ACCORDING TO THE INSTRUCTIONS
warning('YOU HAVE TO COMMENT THIS CODE OUT AND PLACE YOURS');
numPixs = numel(image);
features = zeros( numPixs, 1 ); % just one feature for the example
features(:,1) = image(:);   % just the pixel values as the feature

% REMOVE!!: this is what they have to implement
if true
    
    features = zeros( numPixs, 6 );
    
    sigmas = [1 2 4];
    fIdx = 1;
    
    for sigma = sigmas
        s1 = [-1,-2,-1;...
          0 , 0,0;...
          1, 2, 1];
        s2 = s1';

        gg = imfilter( image, fspecial('gaussian', [15 15], sigma ) );

        Ixx = imfilter(imfilter( gg, s1 ), s1);
        Iyy = imfilter(imfilter( gg, s2 ), s2);
        Ixy = imfilter(imfilter( gg, s1 ), s2);



        lambda_1 = 0.5 * ( Ixx + Iyy - sqrt( (Ixx - Iyy).^2 + 4*Ixy.^2 ) );
        lambda_2 = 0.5 * ( Ixx + Iyy + sqrt( (Ixx - Iyy).^2 + 4*Ixy.^2 ) );

        features(:, fIdx) = lambda_1(:);
        features(:, fIdx+1) = lambda_2(:);
        fIdx = fIdx + 2;
    end
end