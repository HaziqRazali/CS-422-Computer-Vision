% You have to fill in the code in this function for Task 1A
function features = computeTask1AFeatures( image )

% features should be a matrix for which the value
%   features(I,J) is the value of the feature J at pixel I

% This is an example that just places the pixels values in the feature
% matrix
% You HAVE TO RE-IMPLEMENT ACCORDING TO THE INSTRUCTIONS
warning('YOU HAVE TO COMMENT THIS CODE OUT AND PLACE YOURS');
numPixs = numel(image);
features = zeros( numPixs, 1 ); % just one feature for the example
features(:,1) = image(:);   % just the pixel values as the feature

% REMOVE!!: this is what they have to implement
if true
    
    features = zeros( numPixs, 9 );
    
    fIdx = 1;
    
    sigmas = [1.0, 2.0, 4.0];
    
    % Gaussian
    for sigma = sigmas
        k = fspecial('gaussian', [15 15], sigma);
        gauss = imfilter( image, k );

        features(:,fIdx) = gauss(:);
        fIdx = fIdx + 1;
    end


    % Laplacian of Gaussian
    for sigma = sigmas

        k = fspecial('log', [21 21], sigma);
        logg = imfilter( image, k );
        
        features(:,fIdx) = logg(:);
        fIdx = fIdx + 1;
    end

    % Gradient magnitude
    for sigma = sigmas
        s1 = [-1,-2,-1;...
              0 , 0,0;...
              1, 2, 1];
        s2 = s1';

        gg = imfilter( image, fspecial('gaussian', [15 15], sigma ) );

        g1 = imfilter( gg, s1 );
        g2 = imfilter( gg, s2 );
        gm = sqrt(g1.^2 + g2.^2);

        features(:,fIdx) = gm(:);
        fIdx = fIdx + 1;
    end
end