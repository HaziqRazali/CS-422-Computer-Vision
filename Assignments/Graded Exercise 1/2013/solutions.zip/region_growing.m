% You have to fill in the code in this function for Task 2A
function region_mask = region_growing(I,x,y)
% You HAVE TO RE-IMPLEMENT ACCORDING TO THE INSTRUCTIONS
warning('YOU HAVE TO COMMENT THIS CODE OUT AND PLACE YOURS');
region_mask = ones(size(I));

% REMOVE!!: this is what they have to implement
region_mask = zeros(size(I));
[w h] = size(I); 

%reg_mean = I(x,y); 
reg_size = 1; 

seedVal=1; 

neigb= [-1 0; ...
        1 0; ...
        0 -1; ...
        0 1];

neg_list = [];

while(seedVal>0 && reg_size<numel(I))

    for i=1:size(neigb,1)
        xn = x +neigb(i,1); yn = y +neigb(i,2);
        ins=(xn>=1)&&(yn>=1)&&(xn<=w)&&(yn<=h);
        if(ins&&(region_mask(xn,yn)==0)) 
            neg_list = [neg_list; xn yn I(xn,yn)];
            region_mask(xn,yn)=1;
        end
    end

    [seedVal,index] = max(neg_list(:,3));
    region_mask(x,y)=2; reg_size=reg_size+1;
    x = neg_list(index,1); y = neg_list(index,2);
    
    a = 1:size(neg_list,1);
    b = ~(a==index);
    neg_list_copy = neg_list(b,:);
    neg_list = neg_list_copy;

end

region_mask=region_mask>1;

end



