% You have to fill in the code in this function for Task 1A
function features = computeTask1AFeatures( image )

% features should be a matrix for which the value
%   features(I,J) is the value of the feature J at pixel I

% This is an example that just places the pixels values in the feature
% matrix
% You HAVE TO RE-IMPLEMENT ACCORDING TO THE INSTRUCTIONS
warning('YOU HAVE TO COMMENT THIS CODE OUT AND PLACE YOURS');
numPixs = numel(image);
features = zeros( numPixs, 1 ); % just one feature for the example
features(:,1) = image(:);   % just the pixel values as the feature

end
