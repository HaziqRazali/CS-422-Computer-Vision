% You have to fill in the code in this function for Task 2A
function region_mask = region_growing(I,x,y)
% You HAVE TO RE-IMPLEMENT ACCORDING TO THE INSTRUCTIONS
warning('YOU HAVE TO COMMENT THIS CODE OUT AND PLACE YOURS');
region_mask = ones(size(I));



end



