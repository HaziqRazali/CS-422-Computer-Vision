clear all;
close all;
clc;

%% load image
I = imread('coins.png');

%% make edge image
edge_I = zeros(size(I));

%% Implement Hough Transform
% define a range of radii in r
r = [20,25,30];
accum = CircleHough(edge_I,r);

%% Compute local maxima of the parameter space
thres = 40;
[x_c,y_c] = DetectCircles(accum,r,thres);

%% Implement basic visualization
ShowCircles(I,r,x_c,y_c)

