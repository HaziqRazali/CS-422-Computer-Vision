function accum = CircleHough(edge_I,r)

% input:    edge image that can be acquired with the MATLAB function 'edge'
%           and range of radii to be investigated
% output:   accumulation array, where maximums corresponds to the lines in the image

error('Error: Hough Transform: Comment this line in the code and implement you code here');

end

