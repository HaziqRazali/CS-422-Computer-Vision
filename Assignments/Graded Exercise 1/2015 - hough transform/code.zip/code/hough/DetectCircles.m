function [x_c,y_c] = DetectCircles(accum,thres)
%DETECT_CIRCLES Summary of this function goes here
%   Detailed explanation goes here

error('Error: Detect Circles: Comment this line in the code and implement you code here');

end

