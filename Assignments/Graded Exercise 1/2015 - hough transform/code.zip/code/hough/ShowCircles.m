function ShowCircles(I,r,x_c,y_c)
%SHOW_CIRCLES Summary of this function goes here
%   Detailed explanation goes here

error('Error: Show Circles: Comment this line in the code and implement you code here');

end

