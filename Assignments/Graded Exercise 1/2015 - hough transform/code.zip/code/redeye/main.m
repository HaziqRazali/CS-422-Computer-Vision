%% -- Red Eye Correction --
clearvars;
close all;

%% Load Image
img = imread('2010-08-23-redeyereflex.jpg');

%% Results from running the hough transform on the image
x_c = [168; 53]; % x coordinate of each circle
y_c = [65; 46];  % y coordinate of each circle
r_c = [10, 9];    % radius of each circle

%% Your code goes here --

%% Answer the questions here --