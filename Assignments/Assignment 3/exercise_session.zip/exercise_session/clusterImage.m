function [labelImage] = clusterImage(depthImage)
%
% Inputs: 
% 
% depthImageage: An image where each value indicates the depth of the
% corresponding pixel.
%
% Outputs: 
%
% labelImage:  Output label image where each value indicates to which 
% cluster the corresponding pixels belongs. There are three clusters: 
% value 1 for the background, value 2 for the hand and value 3 for 
% the doll.
%

k=3;

% initiate centroids - BEGIN
% we create 3 centroids, in the format [Z X Y], where Z in the inverse depth
mu=zeros(k,3);

mu(1,:) = [0 0 0]; %background centroid
mu(2,:) = [500 300 150]; %hand centroid
mu(3,:) = [1000 100 200]; %doll centroid
% initiate centroids - END

%%TODO: implement kmeans

Error('Implement you k-means function');


end