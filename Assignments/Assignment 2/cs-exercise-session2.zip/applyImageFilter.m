% -- Excercise 2.1, apply filter to image
function R = applyImageFilter( I, F )

error('You have to add your code here!');
