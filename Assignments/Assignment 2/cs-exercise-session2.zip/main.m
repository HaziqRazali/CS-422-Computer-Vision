%%
%% --- Computer Vision Course - Excerice Session 2
% For instructions check the moodle webpage
clearvars;


%% -- Exercise 2.1: Implementing Convolution

% read sample image
img = imread('coins.png');

% convert to DOUBLE, VERY IMPORTANT. Find out why!
img = im2double(img);

% create filter we will convolve img with
% (sobel filter)
filt = [-1, 0, 1; ...
        -2, 0, 2; ...
        -1, 0, 1] * 1/8;
    
% convolve img with filt with the function you wrote
result = applyImageFilter( img, filt );

% show the results
figure(1); clf;
subplot(131); imshow(img); title('Original');
subplot(132); imagesc(filt); axis equal; axis off; title('Filter');
subplot(133); imagesc(result); axis equal; axis off; title('Result');

%% -- Exercise 2.2: Analyzing gradient image
% add your code here

%% -- Exercise 2.3: Computing Gradient Magnitude and Phase
% add your code here

%% Exercise 2.4: Comparing separable and non separable filters
% add your code here
