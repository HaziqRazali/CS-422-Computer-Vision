function bw = thresholding(im,nbins)
%% variables
% im    - input image of size NxM
% nbins - number of bins in the histogram

% bw    - output binary image

%% your implementation starts here

error('Implement your function here');

end

