function bw = adaptive_thresholding(im,sz,threshold)
%% variables
% im        - input image of size NxM
% sz        - size of the window, from which threshold is estimated
% threshold - supplementary threshold

% bw        - output binary image

error('Implement your function here');

end