function [spix] = superpixel(im,sz,diff)
%% variables
% im   - input image, gray level.
% sz   - maximum size of the superpixels
% diff - maximum variation of intensities inside the superpixel

% spix - image of the same size as an input image.
%        Each voxel contains the superpixel number it belongs to.

%% your implementation starts here

error('Implement your function here');
end